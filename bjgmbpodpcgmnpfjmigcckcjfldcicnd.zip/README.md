# chromium-ipfuck
IPFuck for Chromium, port of [IPFlood/IPFuck](http://ipflood.paulds.fr/).

Chrome Web Store: <https://chrome.google.com/webstore/detail/ipfuck/bjgmbpodpcgmnpfjmigcckcjfldcicnd>
